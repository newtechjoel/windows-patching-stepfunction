## Patches instances via SSM automation, identifies instance via instancedata tag
## Will sequentially patch instances based on instance role, "data" database and file servers first, "other" application servers last. Splits patching order into A/B datacenters.
## https://github.com/newtechjoel
import boto3
import sys
import json
import time

def getinstances(ec2):
    # Get Instances
    try:
        reservations = ec2.describe_instances(Filters=[{'Name': 'tag-key', 'Values': ['instancedata']}])['Reservations']
        instance_reservations = [[i for i in r['Instances']] for r in reservations]
        instances = []
        for instance_reservation in instance_reservations:
            for this_instance in instance_reservation:
                if this_instance['State']['Name'] != 'terminated':
                    instances.append(this_instance)
        return instances

    except Exception as e:
        print(e)
        message = 'Error, ec2 describe instances failed'
        print(message)
        raise Exception(message)
    
def checkforautoscaletag(tags):
    # Separate loop for determining if a tag contains a key indicating it is an autoscaling instance. This will skip these instances in the getinstancesdata or getinstancesother function loops.
    for tag in tags:
        if 'aws:autoscaling:groupName' in tag['Key']:
            autoscaleName = tag['Key']
            if autoscaleName == "aws:autoscaling:groupName":
                autoscale = "True"
                return autoscale

def getinstancesother(instances, solution, environment):
     # Filter other instance's based on tag values for solution, environment and instancedata tag definition
    targeted_instances_other = []
    for ins in instances:
        tags = ins['Tags']
        if checkforautoscaletag(tags) == "True":
            continue
        else:
            for tag in tags:
                if 'instancedata' in tag['Key']:
                    selectedTagValue = json.loads(tag['Value'])
                    if solution in selectedTagValue['solution'].lower() and environment in selectedTagValue['environment'].lower():
                        if ('Application Server'.lower() in selectedTagValue['instance'].lower()
                            or 'Web Server'.lower() in selectedTagValue['instance'].lower()
                            or 'Windows'.lower() in selectedTagValue['instance'].lower() 
                            or 'SQL Witness'.lower() in selectedTagValue['instance'].lower()):
                                targeted_instances_other.append(ins)
                        else:
                            continue
                    else:
                        continue
                else:
                    continue
        
    return targeted_instances_other
    
def getinstancesdata(instances, solution, environment):
    # Filter data instance's based on tag values for solution, environment and instancedata instance definition
    targeted_instances_data = []
    for ins in instances:
        tags = ins['Tags']
        if checkforautoscaletag(tags) == "True":
            continue
        else:
            for tag in tags:
                if 'instancedata' in tag['Key']:
                    selectedTagValue = json.loads(tag['Value'])
                    if solution in selectedTagValue['solution'].lower() and environment in selectedTagValue['environment'].lower():
                        if ('SQL Server'.lower() in selectedTagValue['instance'].lower()
                            or 'Postgresql Server'.lower() in selectedTagValue['instance'].lower() 
                            or 'File Server'.lower() == selectedTagValue['instance'].lower()):
                                targeted_instances_data.append(ins)
                        else:
                            continue
                    else:
                       continue
                else:
                    continue
    return targeted_instances_data

def getinstance_az(instances, az_zone):
    instance_az_instances = []
    for ins in instances:
        if az_zone in ins['Placement']['AvailabilityZone']:
            instance_az_instances.append(ins)
    return instance_az_instances
    
def powerOnInstances(ec2, instances):
    # Check instance status and powers instances if necessary
    for ins in instances:
        currentState = ins['State']['Name']
        if 'running' in currentState:
            continue
        elif 'stopped' in currentState:
            ec2.start_instances(InstanceIds=[ins['InstanceId']])
            time.sleep(60)
        elif 'shutting-down' in currentState:
            while True:
                time.sleep(15)
                status = ec2.describe_instance_status(InstanceIds=[ins['InstanceId']])
                if "stopped" in status['InstanceStatuses']['InstanceState']['Name']:
                    ec2.start_instances(InstanceIds=[ins['InstanceId']])
                    time.sleep(60)
                    break
                else:
                    continue
        elif 'pending' in currentState:
            continue

def execute_automation(ssm, documentName, instances, solution, environment):
    autoId = []
    if instances:
        try:
            for i in instances:
                #Load Instance tag
                tags = i['Tags']
                for tag in tags:
                    if 'instancedata' in tag['Key']:
                        selectedTagValue = json.loads(tag['Value'])
                        instanceType = selectedTagValue['instance']
                        
                #Submit ssm automation
                response = ssm.start_automation_execution(
                    DocumentName=documentName,
                    Parameters= {
                    'SolutionName': [solution], 
                        'EnvironmentName': [environment], 
                        'Tier': [instanceType], 
                        'InstanceId': [i['InstanceId']]
                        }
                    )
                autoId.append(response['AutomationExecutionId'])
            return autoId
        
        except Exception as e:
            print(e)
            message = 'Error submitting SSM Automation Execution'
            print(message)
            raise Exception(message)
    else:
        return autoId

def getDocument(ssm):
    # Find name of SSM Document through filter
    document = ssm.list_documents(
    DocumentFilterList=[
    {
        'key': 'Owner',
        'value': 'Self',
    }
    ],MaxResults=50)
    try:
        documentList = document['DocumentIdentifiers']
        for docs in documentList:
            tags = docs['Tags']
            for values in tags:
                if values['Key'] == 'patchingDocument':
                    specificDoc = docs
        documentName = specificDoc['Name']
    except Exception as e:
        print(e)
        message = 'Error, No SSM document with matching tag found'
        print(message)
        raise Exception(message)
    return documentName

def lambda_handler(event, context):
    # Creating AWS low level clients and getting instances filtered against solution and environment
    aws_region = event['patchinginfo']['region']
    solution = (event['patchinginfo']['solution']).lower()
    environment = event['patchinginfo']['environment'].lower()
    try:
        nextZone = event['patchinginfo']['nextZone']
    except:
        nextZone = "Step 1 Data Instances A"
    currentZone = nextZone
    ec2 = boto3.client('ec2', region_name=aws_region)
    ssm = boto3.client('ssm', region_name=aws_region)
    documentName = getDocument(ssm)
    
    # Reset Retry Count to 1 for the next set of instances
    retryValue = 1

    # Get instances and filter
    instances = getinstances(ec2)
    
    # Filter instances to be patched further based on passed in values, power on if needed and execute SSM automation 
    try:
        if "Step 1 Data Instances A" in currentZone:
            instances_topatch = getinstancesdata(instances, solution, environment)
            targeted_instances = getinstance_az(instances_topatch, (aws_region+"a"))
            powerOnInstances(ec2, targeted_instances)
            autoId = execute_automation(ssm, documentName, targeted_instances, solution, environment)
            nextZone = "Step 2 Data Instances B or C"
        
        if "Step 2 Data Instances B or C" in currentZone:
            instances_topatch = getinstancesdata(instances, solution, environment)
            targeted_instances_in_b = getinstance_az(instances_topatch, (aws_region+"b"))
            targeted_instances_in_c = getinstance_az(instances_topatch, (aws_region+"c"))
            targeted_instances = targeted_instances_in_b + targeted_instances_in_c
            powerOnInstances(ec2, targeted_instances)
            autoId = execute_automation(ssm, documentName, targeted_instances, solution, environment)
            nextZone = "Step 3 Application Instances A"
     
        if "Step 3 Application Instances A" in currentZone:
            instances_topatch = getinstancesother(instances, solution, environment)
            targeted_instances = getinstance_az(instances_topatch, (aws_region+"a"))
            powerOnInstances(ec2, targeted_instances)
            autoId = execute_automation(ssm, documentName, targeted_instances, solution, environment)
            nextZone = "Step 4 Application Instances B or C"
    
        if "Step 4 Application Instances B or C" in currentZone:
            instances_topatch = getinstancesother(instances, solution, environment)
            targeted_instances_in_b = getinstance_az(instances_topatch, (aws_region+"b"))
            targeted_instances_in_c = getinstance_az(instances_topatch, (aws_region+"c"))
            targeted_instances = targeted_instances_in_b + targeted_instances_in_c
            powerOnInstances(ec2, targeted_instances)
            autoId = execute_automation(ssm, documentName, targeted_instances, solution, environment)
    
    except Exception as e:
        print(e)
        message = 'Error, cannot parse instances'
        print(message)
        raise Exception(message) 
    
    # Return JSON to step function
    return { 
        "patchinginfo" : {
        "solution" : solution,
        "environment" : environment,
        "currentZone" : currentZone,
        "nextZone": nextZone,
        "retryCounter": retryValue,
        "region": aws_region,
        "automationids": autoId
            }
        }
    

