## Patches instances via SSM automation, identifies instance via instancedata tag
## Will sequentially patch instances based on instance role, "data" database and file servers first, "other" application servers last. Splits patching order into A/B datacenters.
## https://github.com/newtechjoel
import json
import boto3

def lambda_handler(event, context):
    
    # Create data structures and get details of automation id's
    print("Received event: " + json.dumps(event, indent=2))
    ssm = boto3.client('ssm')
    automationList = []
    status = {}
    currentStatus = []
    status['patchinginfo'] = event['patchinginfo']
    automationList = event['patchinginfo']['automationids']
    print(status)
    if automationList:
        for al in automationList: 
            autostatus = (ssm.get_automation_execution(AutomationExecutionId=al)['AutomationExecution']['AutomationExecutionStatus'])
            if autostatus in ['Waiting', 'InProgress']:
                status['patchinginfo']['status'] = 'WAITING'
                return status
         
            if autostatus in ['Failed', 'TimedOut', 'Cancelling', 'Cancelled']:
                status['patchinginfo']['status'] = 'FAILED'
                return status
                
            if autostatus in ['Success']:
                currentStatus.append('SUCCEEDED')
                pass
        
        if 'SUCCEEDED' in currentStatus:
            status['patchinginfo']['status'] = 'SUCCEEDED'
            return status
    else:
        status['patchinginfo']['status'] = 'SUCCEEDED'
        return status