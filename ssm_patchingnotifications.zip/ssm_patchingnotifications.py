## Patches instances via SSM automation, identifies instance via instancedata tag.
## Will sequentially patch instances based on instance role, "data" database and file servers first, "other" application servers last. Splits patching order into A/B datacenters.
## SES addresses must be pre approved, this is out of scope of this function.
## https://github.com/newtechjoel

import boto3
import os

def checkEmail(ses, contactToEmail, contactFromEmail):
    listSES = ses.list_identities(
    IdentityType='EmailAddress',
    MaxItems=123
    )
    getCurrentVerified = listSES['Identities']
    if contactToEmail in getCurrentVerified:
        pass
    else:
        newToEmail = ses.verify_email_identity(
            EmailAddress=contactToEmail
            )
            
    if contactFromEmail in getCurrentVerified:
        pass
    else:
        newFromEmail = ses.verify_email_identity(
            EmailAddress=contactFromEmail
            )

def patchSuccess(solution, environment):
    # Email Body
    MAIL_TEXT = f"""<pre><font face="calibri" size="3">Hello ,

 Patching operation in environment <b>{environment}</b> for solution <b>{solution}</b>  has been completed successfully.

Please do not reply to this email.
Regards,
Cloud Team</font></pre>
    """
    return MAIL_TEXT

def patchFailure(aws_region, environment, solution, autoId, currentZone):
    # Get some extra error detail
    ssm = boto3.client('ssm', region_name=aws_region)
    for a in autoId:
        action = ssm.describe_automation_executions(
        Filters=[
        {
            'Key': 'ExecutionId',
            'Values': [a]
        },
        ],
        MaxResults=50
        )
        errorMessage = action['AutomationExecutionMetadataList']
        if errorMessage:
            for properties in errorMessage:
                if 'TimedOut' in properties['AutomationExecutionStatus'] or 'Failed' in properties['AutomationExecutionStatus'] or 'Cancelled' in properties['AutomationExecutionStatus']:
                    failureMessage = properties['FailureMessage']
                    startTime = properties['ExecutionStartTime']
                    endTime = properties['ExecutionEndTime']
                    failureStatus = properties['AutomationExecutionStatus']
                    failureOutput = properties['Outputs']
                    aID = properties['AutomationExecutionId']
                else:
                    pass
        else:
            pass
    
    # Email Body
    MAIL_TEXT = f"""<pre><font face="calibri" size="3">Hello,

Unfortunately the following patching automation has failed at <b>{currentZone}</b> in Environment <b>{environment}</b> for Solution <b>{solution}</b>.

The following automation's may have failed, these are listed below: 
{autoId}

Some additional troubleshooting information.
<b>Automation ExecutionId</b>: {aID}
<b>Failure message:</b> {failureMessage}
<b>Current status of task:</b> {failureStatus}
<b>Automation StartTime:</b> {startTime}
<b>Automation EndTime:</b> {endTime}
    
Please do not reply to this email.
Regards,
Cloud Team</font></pre>
    """
    return MAIL_TEXT


def lambda_handler(event, context):
    #  Retrieve values from step JSON
    aws_region = event['patchinginfo']['region']
    solution = event['patchinginfo']['solution']
    environment = event['patchinginfo']['environment']
    currentZone = event['patchinginfo']['currentZone']
    status = event['patchinginfo']['status']
    autoId = event['patchinginfo']['automationids']
    ses = boto3.client('ses', region_name = 'us-east-1')
    contactFromEmail = os.environ['contactToEmail']
    contactToEmail = os.environ['contactFromEmail']
    
    # Check email addresses are present and create new email addresses based on inputs from cloudformation if unavailable.
    try:
        checkEmail(ses, contactToEmail, contactFromEmail)
    except Exception:
            message = 'Error, cannot verify contact email identities or create new verified email identities'
            print(message)
            raise Exception(message)
    
    # Send email based on status
    try:
        if "FAILED" in status:
            emailBody = patchFailure(aws_region, environment, solution, autoId, currentZone)
            emailSubject = f"##Patching Failed## {solution}. {currentZone} in environment {environment} for solution {solution} has failed."
        elif "SUCCEEDED" in status:
            emailBody = patchSuccess(solution, environment)
            emailSubject = f"##Patching Succeeded## {solution}. Patching operation for environment {environment} for solution {solution} has succeeded."
        else:
            pass
    
    
    except Exception as e:
        print(e)
        message = 'Error, cannot retrieve values for email body'
        print(message)
        raise Exception(message) 
        
    # Send Email
    mail_response = ses.send_email(
        Source=contactFromEmail,
        Destination={
            'ToAddresses': [contactToEmail]
        },
        Message={
            'Subject': {
                'Data': emailSubject % {},
                'Charset': 'UTF-8'
            },
                'Body': {
                    'Html': {
                        'Data':emailBody % {
                        },
                        'Charset': 'UTF-8',
                    }
                }
            }
        )
    print('INFO: mail sent with id %s' % mail_response['MessageId'])
