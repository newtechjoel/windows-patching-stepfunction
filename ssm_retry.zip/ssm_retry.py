## Patches instances via SSM automation, identifies instance via instancedata tag
## Will sequentially patch instances based on instance role, "data" database and file servers first, "other" application servers last. Splits patching order into A/B datacenters.
## https://github.com/newtechjoel
import boto3
import os

def execute_automation(ssm, instances, solution, environment):
    
    # Find name of SSM Document through filter
    document = ssm.list_documents(
    DocumentFilterList=[
    {
        'key': 'Owner',
        'value': 'Self',
    }
    ],MaxResults=50)
    try:
        documentList = document['DocumentIdentifiers']
        for docs in documentList:
            tags = docs['Tags']
            for values in tags:
                if values['Key'] == 'patchingDocument':
                    specificDoc = docs
        documentName = specificDoc['Name']
    except Exception as e:
        print(e)
        message = 'Error, No SSM document with matching tag found'
        print(message)
        raise Exception(message) 
   
    # Start SSM automation based on passed in ID
    autoId = []
    if instances:
        try:
            for i in instances:
                #Submit ssm automation
                response = ssm.start_automation_execution(
                    DocumentName=documentName,
                    Parameters= {
                    'SolutionName': [solution], 
                        'EnvironmentName': [environment], 
                        'Tier': i['Tier'], 
                        'InstanceId':i['InstanceId']
                        }
                    )
                autoId.append(response['AutomationExecutionId'])
                
            return autoId
        
        except Exception as e:
            print(e)
            message = 'Error submitting SSM Automation Execution'
            print(message)
            raise Exception(message)
    else:
        return autoId
        
        
def queryautomations(ssm, automationList):
    
    # Query Failed SSM automations
    failedautomations = []
    if automationList:
        for al in automationList: 
            autostatus = (ssm.get_automation_execution(AutomationExecutionId=al)['AutomationExecution']['AutomationExecutionStatus'])
            
            if autostatus in ['Success']:
                continue

            if autostatus in ['Waiting', 'InProgress']:
                continue
         
            if autostatus in ['Failed', 'TimedOut', 'Cancelling', 'Cancelled']:
                instanceparameters = (ssm.get_automation_execution(AutomationExecutionId=al)['AutomationExecution']['Parameters'])
                failedautomations.append(instanceparameters)
                
        return failedautomations

def patchFailure(aws_region, environment, solution, automationList, currentZone, ssm):
    # Get some extra error detail
    for a in automationList:
        action = ssm.describe_automation_executions(
        Filters=[
        {
            'Key': 'ExecutionId',
            'Values': [a]
        },
        ],
        MaxResults=50
        )
        
        errorMessage = action['AutomationExecutionMetadataList']
        if errorMessage:
            for properties in errorMessage:
                if 'TimedOut' in properties['AutomationExecutionStatus'] or 'Failed' in properties['AutomationExecutionStatus'] or 'Cancelled' in properties['AutomationExecutionStatus']:
                    failureMessage = properties['FailureMessage']
                    startTime = properties['ExecutionStartTime']
                    endTime = properties['ExecutionEndTime']
                    failureStatus = properties['AutomationExecutionStatus']
                    aID = properties['AutomationExecutionId']
                    
                    automationDetails = ssm.get_automation_execution(AutomationExecutionId = a)
                    instanceId = automationDetails['AutomationExecution']['Parameters']['InstanceId']
                    instanceId = ''.join(instanceId)
                    
            
                else:
                    pass
        
        else:
            pass
        
       
    
    
    # Email Body
    MAIL_TEXT = f"""<pre><font face="calibri" size="3">Hello Admins,

Unfortunately the following patching automation has failed at <b>{currentZone}</b> in Environment <b>{environment}</b> for Solution <b>{solution}</b> on Instance <b>{instanceId}</b>.

This automation will retry up to 3 times before the overall patching operation will fail with an additional email.

Some additional troubleshooting information.
<b>InstanceID:</b> {instanceId}
<b>Automation ExecutionId:</b> {aID}
<b>Failure message:</b> {failureMessage}
<b>Current status of task:</b> {failureStatus}
<b>Automation StartTime:</b> {startTime}
<b>Automation EndTime:</b> {endTime}
    
Please do not reply to this email.
Regards,
Cloud Team</font></pre>
    """
    return MAIL_TEXT

def lambda_handler(event, context):
    
    # Create data structures and get details of automation id's
    ssm = boto3.client('ssm')
    ses = boto3.client('ses', region_name = 'us-east-1')
    aws_region = event['patchinginfo']['region']
    solution = (event['patchinginfo']['solution']).lower()
    environment = event['patchinginfo']['environment'].lower()
    automationList = event['patchinginfo']['automationids']
    nextZone = event['patchinginfo']['nextZone']
    currentZone = event['patchinginfo']['currentZone']
    retryValue = event['patchinginfo']['retryCounter']
    automations = []
    
    # Query Automation status of instances in zone
    instances = queryautomations(ssm, automationList)
  
    # Rerun all failed automations
    automations = execute_automation(ssm, instances, solution, environment)
    
    # Increment Retry Counter
    if retryValue:
        retryValue = retryValue + 1
    else:
        retryValue = 1
        
    # Send email of patching automation failure
    try:
    
        emailBody = patchFailure(aws_region, environment, solution, automationList, currentZone, ssm)
        emailSubject = f"##Single Automation Failed {retryValue} out of 3## in {solution}. {currentZone} in Environment {environment} for Solution {solution} has failed. This zone has attempted to patch {retryValue} times out of 3."
        
        #actual email code        
        MAIL_FROM = os.environ['contactToEmail']
        MAIL_TO = os.environ['contactFromEmail']
        mail_response = ses.send_email(
            Source=MAIL_FROM,
            Destination={
                'ToAddresses': [MAIL_TO]
            },
            Message={
                'Subject': {
                    'Data': emailSubject % {},
                    'Charset': 'UTF-8'
                },
                    'Body': {
                        'Html': {
                            'Data':emailBody % {
                            },
                            'Charset': 'UTF-8',
                        }
                    }
                }
        )
            
    except Exception as e:
        print(e)
        message = 'Error, cannot retrieve values for email body'
        print(message)
        raise Exception(message) 
        
    # Return JSON to step machine
    return { 
    "patchinginfo" : {
    "solution" : solution,
    "environment" : environment,
    "currentZone" : currentZone,
    "nextZone": nextZone,
    "region": aws_region,
    "automationids": automations,
    "retryCounter": retryValue
        }
    }